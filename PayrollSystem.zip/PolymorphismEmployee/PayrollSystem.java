package Polymorphism;
import java.util.*;
public class PayrollSystem {
    
    public static void main(String [] args){
        List<Employee> employees = new ArrayList<>();
        employees.add(new FullTimeEmployee("Alice", 3000));
        employees.add(new PartTimeEmployee("Bob", 15, 80));
        employees.add(new CommissionEmployee("Cara", 1500, 20000, 0.05));
        employees.add(new Contractor("Dan", 800, 3));
        employees.add(new CommissionEmployee("John", 1000, 3000, 0.9));//1000 + (3000*0.9)
        runPayRoll(employees);
    }
    public static void runPayRoll(List<Employee> employees){
        int total = 0;
        for (Employee e : employees) {
            System.out.println("Name : " + e.getName() + "\nRole : " + e.getRole() + "\nOverall Pay :" + e.calculatePay() );
            System.out.println("-------------------------------------------");
            total++;
        }

        System.out.println("Total payroll: " + total);
    }
}

