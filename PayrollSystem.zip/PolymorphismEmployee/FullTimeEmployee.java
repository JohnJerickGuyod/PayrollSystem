package Polymorphism;

public class FullTimeEmployee extends Employee {
    double monthlySalary;
    FullTimeEmployee(String name, double monthlySalary){
        super(name);
        this.monthlySalary = monthlySalary;
    }
    @Override
    public double calculatePay(){
        return monthlySalary;
    }
    @Override 
    public String getRole(){
        return "FullTimeEmployee";
    }
}
