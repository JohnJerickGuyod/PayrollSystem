package Polymorphism;

public class Employee {
    private String name;
    Employee(String name){
        this.name = name;
    }

    public double calculatePay(){
        return 0.0;
    }
    public String getRole(){
        return "Employee";
    }
    public String getName(){
        return this.name;
    }
}
