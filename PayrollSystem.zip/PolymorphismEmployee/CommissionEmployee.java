package Polymorphism;

public class CommissionEmployee extends Employee{
    double baseSalary;
    double sales;
    double commissionRate;
    
    CommissionEmployee(String name,double baseSalary,double sales,double commissionRate){
        super(name);
        this.baseSalary = baseSalary;
        this.sales = sales;
        this.commissionRate = commissionRate;
    }
    @Override
    public double calculatePay(){
        return this.baseSalary + (this.sales * this.commissionRate);
    }
    @Override 
    public String getRole(){
        return "CommissionEmployee";
    }
}
