package Polymorphism;

public class Contractor extends Employee {
     double projectFee;
     int projectsCompleted;

    Contractor(String name,double projectFee, int projectsCompleted){
        super(name);
        this.projectFee = projectFee;
        this.projectsCompleted = projectsCompleted;
    }
    
    @Override
    public double calculatePay(){
        return this.projectFee * this.projectsCompleted;
    }
    @Override 
    public String getRole(){ 
        return "Contractor";
    }
}
