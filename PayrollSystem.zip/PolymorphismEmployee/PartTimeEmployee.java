package Polymorphism;

public class PartTimeEmployee extends Employee {
    double hourlyRate;
    double hoursWorked;

    PartTimeEmployee(String name,double hourlyRate,double hoursWorked){
        super(name);
        this.hourlyRate = hourlyRate;
        this.hoursWorked = hoursWorked;
    }
    @Override
    public double calculatePay(){
        return hourlyRate * hoursWorked;
    }
    @Override 
    public String getRole(){
        return "PartTimeEmployee";
    }
}

